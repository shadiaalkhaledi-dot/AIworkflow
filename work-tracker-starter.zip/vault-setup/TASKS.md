# Tasks

_Claude keeps this file current. At the start of each session, Claude reads it alongside your tracker and helps you triage what's changed._

**Optional — site metadata tags:** if you want your tracker site's filters (category, discipline, priority, who it's waiting on, urgency) to work off real data instead of Claude guessing each time, add bracketed tags to the end of a task line: `[cat:: value] [disc:: value] [action:: value] [court:: value] [horizon:: value]`. Not required — Claude can still triage without them — but the more of these you fill in, the less Claude has to infer, and the more your tracker's filters actually mean something. Example below.

---

## Today's Focus



## Open — In Your Court

- [ ] Example: Follow up with vendor on quote [cat:: coordination] [disc:: general] [action:: chase] [court:: You] [horizon:: today]

## Blocked (waiting on others)

- [ ] Example: Waiting on client sign-off before proceeding [cat:: decisions] [court:: Client Name] [delegate:: Jordan] [horizon:: watch]

## Watch List (monitoring, low priority)

- [ ] Example: Keeping an eye on a possible schedule change, nothing to do yet [cat:: documentation] [court:: You] [horizon:: watch]

## Completed This Week

