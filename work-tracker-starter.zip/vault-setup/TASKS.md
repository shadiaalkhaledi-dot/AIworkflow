# Tasks

_Claude keeps this file current. At the start of each session, Claude reads it alongside your tracker and helps you triage what's changed._

---

## Today's Focus



## Open — In Your Court



## Blocked (waiting on others)



## Watch List (monitoring, low priority)



## Completed This Week


