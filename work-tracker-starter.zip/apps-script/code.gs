// ============================================================
// Work Tracker — Google Apps Script (Quick Capture)
// Deploy this as a Web App in Google Sheets:
//   Extensions → Apps Script → paste this → Deploy → New deployment
//   Type: Web app  |  Execute as: Me  |  Access: Anyone
//   Copy the web app URL → paste into data.json as "apiUrl"
// ============================================================

var SHEET_NAME = 'Captures';

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    if (!sheet) sheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_NAME);

    // Edit existing row
    if (data.action === 'edit' && data.row) {
      sheet.getRange(data.row, 1, 1, 6).setValues([[
        data.ts     || new Date().toISOString(),
        data.type   || '',
        data.program|| '',
        data.pkg    || '',
        data.itemRef|| '',
        data.text   || ''
      ]]);
      return out({ok: true});
    }

    // Append new row
    sheet.appendRow([
      data.ts     || new Date().toISOString(),
      data.type   || 'item',
      data.program|| '',
      data.pkg    || '',
      data.itemRef|| '',
      data.text   || ''
    ]);
    return out({ok: true, row: sheet.getLastRow()});

  } catch(err) {
    return out({ok: false, error: err.toString()});
  }
}

function doGet(e) {
  try {
    if (e.parameter.action === 'pending') {
      var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
      if (!sheet) return out([]);
      var data = sheet.getDataRange().getValues();
      var rows = [];
      for (var i = 1; i < data.length; i++) {
        rows.push({
          row:     i + 1,
          ts:      data[i][0],
          type:    data[i][1],
          program: data[i][2],
          pkg:     data[i][3],
          itemRef: data[i][4],
          text:    data[i][5]
        });
      }
      return out(rows);
    }
    return out({ok: true, status: 'running'});
  } catch(err) {
    return out({ok: false, error: err.toString()});
  }
}

function out(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
