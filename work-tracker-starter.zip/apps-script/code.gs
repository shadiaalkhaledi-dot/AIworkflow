/**
 * Work Tracker — Quick Capture backend.
 *
 * Setup:
 * 1. Create a new Google Sheet (any name, e.g. "Work Tracker Capture").
 * 2. Extensions > Apps Script. Delete any boilerplate, paste this whole file in.
 * 3. Deploy > New deployment > type "Web app".
 *    - Execute as: Me
 *    - Who has access: Anyone with the link
 * 4. Copy the Web App URL it gives you.
 * 5. Paste the URL into data.json's "apiUrl" field — the tracker page reads it from
 *    there, you never edit index.html for this.
 *
 * The sheet tab "Log" is created automatically the first time anything is added.
 *
 * Columns: Timestamp | Type | Program | Package | ItemRef | Text | Synced
 *   Type    = item | note | complete | blocker | watch | subtask
 *   Package = the package/sub-group within the program, if one was picked
 *   ItemRef = for note/blocker/watch/subtask: the existing item text this refers to
 *   Synced  = N until Claude reads it and folds it into your task list, then Y.
 *
 * Editing a pending row: the page's "Edit" button POSTs {action:'edit', row, type,
 * program, pkg, itemRef, text} — see handleEdit() below. Only rows still Synced=N
 * are ever shown for editing, so this never touches something already folded in.
 */

var LOG_HEADER = ['Timestamp', 'Type', 'Program', 'Package', 'ItemRef', 'Text', 'Synced'];

function getSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Log');
  if (!sheet) {
    sheet = ss.insertSheet('Log');
    sheet.appendRow(LOG_HEADER);
    sheet.setFrozenRows(1);
    return sheet;
  }
  var lastCol = sheet.getLastColumn();
  var header = lastCol ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
  if (header.indexOf('Package') === -1 || header.indexOf('ItemRef') === -1) {
    if (sheet.getLastRow() <= 1) {
      sheet.clear();
      sheet.appendRow(LOG_HEADER);
      sheet.setFrozenRows(1);
    } else {
      sheet.insertColumns(4, 2);
      sheet.getRange(1, 4, 1, 2).setValues([['Package', 'ItemRef']]);
    }
  }
  return sheet;
}

function doPost(e) {
  var sheet = getSheet();
  var data = JSON.parse(e.postData.contents);

  if (data.action === 'edit') {
    return handleEdit(sheet, data);
  }

  sheet.appendRow([
    new Date(),
    data.type || '',
    data.program || '',
    data.pkg || '',
    data.itemRef || '',
    data.text || '',
    'N'
  ]);
  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function handleEdit(sheet, data) {
  var row = Number(data.row);
  if (!row || row < 2 || row > sheet.getLastRow()) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: 'Invalid row' }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  sheet.getRange(row, 2, 1, 5).setValues([[
    data.type || '',
    data.program || '',
    data.pkg || '',
    data.itemRef || '',
    data.text || ''
  ]]);
  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  var sheet = getSheet();
  var action = (e.parameter.action || 'pending');

  if (action === 'markSynced') {
    var rows = JSON.parse(e.parameter.rows || '[]');
    rows.forEach(function (r) {
      sheet.getRange(r, 7).setValue('Y');
    });
    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, marked: rows.length }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  var values = sheet.getDataRange().getValues();
  var out = [];
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][6]) === 'N') {
      out.push({
        row: i + 1,
        ts: values[i][0],
        type: values[i][1],
        program: values[i][2],
        pkg: values[i][3],
        itemRef: values[i][4],
        text: values[i][5]
      });
    }
  }
  return ContentService
    .createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}
