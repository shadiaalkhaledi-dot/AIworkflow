"""Encrypt data.json -> data.enc.json for the password-gated Work Tracker.

Usage:
    python encrypt_data.py data.json data.enc.json --password 'your-own-password'

PBKDF2-HMAC-SHA256 (310k iterations) -> AES-256-GCM, WebCrypto-compatible.
Deploy data.enc.json + index.html only. NEVER push the plain data.json.
Requires: pip install cryptography
"""
import argparse, base64, hashlib, json, os, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ITERATIONS = 310_000

def encrypt(plaintext, password):
    salt, iv = os.urandom(16), os.urandom(12)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, ITERATIONS, dklen=32)
    ct = AESGCM(key).encrypt(iv, plaintext, None)
    b64 = lambda b: base64.b64encode(b).decode()
    return {'v': 1, 'iter': ITERATIONS, 'salt': b64(salt), 'iv': b64(iv), 'ct': b64(ct)}

def decrypt(enc, password):
    b64d = base64.b64decode
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), b64d(enc['salt']), enc['iter'], dklen=32)
    return AESGCM(key).decrypt(b64d(enc['iv']), b64d(enc['ct']), None)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('infile'); ap.add_argument('outfile'); ap.add_argument('--password', required=True)
    a = ap.parse_args()
    plaintext = open(a.infile, 'rb').read()
    json.loads(plaintext)
    enc = encrypt(plaintext, a.password)
    assert decrypt(enc, a.password) == plaintext, 'round-trip failed'
    json.dump(enc, open(a.outfile, 'w'))
    print(f'Wrote {a.outfile}. Round-trip verified.', file=sys.stderr)
