"""Work Tracker generator: vault markdown -> data.json.

Usage:
    python parse_tasks.py Tasks.md [RFIs.md ...] --prev data.json --out data.json.new
"""

import argparse
import hashlib
import json
import re
import sys
from datetime import date

STATUS_CALLOUT = {'danger': 'blocking', 'todo': 'open', 'warning': 'unverified',
                  'quote': 'watch', 'success': 'completed'}
META_FIELDS = ['cat', 'disc', 'action', 'court', 'delegate', 'horizon', 'pri']

ENUMS = {
    'status': {'open', 'blocking', 'unverified', 'watch', 'completed'},
    'cat': {'decisions', 'meetings', 'coordination', 'documentation', 'drawings', 'rfi'},
    'action': {'model', 'review', 'coordinate', 'chase', 'admin'},
    'horizon': {'today', 'sprint', 'week', 'watch'},
}
DISC_ENUM = {'AR', 'ST', 'ME', 'EL', 'signage', 'safety', 'security', 'owner'}


def stable_id(program, pkg, title):
    return 'v' + hashlib.sha1(f'{program}|{pkg}|{title}'.encode()).hexdigest()[:8]


def norm_title(t):
    return re.sub(r'\s+', ' ', t).strip().lower()


def extract_meta_tags(body):
    found = {}

    def repl(m):
        key, val = m.group(1).strip().lower(), m.group(2).strip()
        if key in META_FIELDS:
            if key == 'disc':
                found[key] = [v.strip() for v in val.split(',') if v.strip()]
            else:
                found[key] = val
            return ''
        return m.group(0)

    clean = re.sub(r'\[(\w+)::\s*([^\]]+)\]', repl, body)
    return re.sub(r'\s{2,}', ' ', clean).strip(), found


def parse_tasks_md(text):
    program = pkg = status = current_item = None
    items, details = [], {}
    for raw in text.split('\n'):
        if m := re.match(r'^##\s+(.+?)\s*$', raw):
            program, pkg, status, current_item = m.group(1), None, None, None
            continue
        if (m := re.match(r'^###\s+(.+?)\s*$', raw)) and program:
            pkg, status, current_item = m.group(1), None, None
            continue
        if (m := re.match(r'^>\s*\[!(\w+)\][+-]?\s*(.*)$', raw)) and program:
            status, current_item = STATUS_CALLOUT.get(m.group(1)), None
            continue
        if (m := re.match(r'^>\s-\s\[([ xX])\]\s+(.*)$', raw)) and program and status:
            done, body = m.group(1).lower() == 'x', m.group(2)
            body = re.sub(r'<span[^>]*>.*?</span>\s*', '', body)
            blocking = bool(re.search(r'\*\*Blocking', body, re.I))
            watch = bool(re.search(r'\*\*Watch', body, re.I))
            due_m = re.search(r'\U0001F4C5\s*(\d{4}-\d{2}-\d{2})', body)
            raised_m = re.search(r'➕\s*(\d{4}-\d{2}-\d{2})', body)
            clean = re.sub(r'\*\*(Blocking|Watch)[^*]*—\*\*\s*', '', body, flags=re.I)
            clean = re.sub(r'\U0001F4C5\s*\d{4}-\d{2}-\d{2}(\s*\([^)]*\))?', '', clean)
            clean = re.sub(r'➕\s*\d{4}-\d{2}-\d{2}', '', clean)
            clean, meta_tags = extract_meta_tags(clean)
            final_status = 'completed' if done else ('blocking' if blocking else ('watch' if watch else status))
            item = {'id': stable_id(program, pkg or '', clean), 'title': clean.strip(),
                    'status': final_status, 'program': program, 'pkg': pkg or ''}
            if due_m:
                item['due'] = due_m.group(1)
            if raised_m:
                item['date'] = raised_m.group(1)
            for f in META_FIELDS:
                if f in meta_tags:
                    item[f] = meta_tags[f]
            items.append(item)
            current_item = len(items) - 1
            details[item['id']] = {'next': None, 'subtasks': [], 'updates': []}
            continue
        if (m := re.match(r'^>\s{2,}-\s(.*)$', raw)) and current_item is not None:
            iid, body = items[current_item]['id'], m.group(1)
            if nm := re.match(r'^\U0001F51C\s*\*\*Next:\*\*\s*(.*)$', body):
                details[iid]['next'] = nm.group(1).strip()
            elif cm := re.match(r'^\[([ xX])\]\s+(.*)$', body):
                details[iid]['subtasks'].append(cm.group(2).strip())
            elif dm := re.match(r'^(\d{4}-\d{2}-\d{2}):\s*(.*)$', body):
                details[iid]['updates'].append(f'{dm.group(1)}|{dm.group(2).strip()}')
    return items, details


def validate(items, details):
    errors = []
    ids = set()
    for it in items:
        if it['id'] in ids:
            errors.append(f"duplicate id: {it['id']} ({it['title'][:40]})")
        ids.add(it['id'])
        for field, allowed in ENUMS.items():
            if field in it and it[field] not in allowed:
                errors.append(f"{it['id']}: {field}='{it[field]}' not in {allowed}")
        if 'disc' in it:
            bad = [d for d in it['disc'] if d not in DISC_ENUM]
            if bad:
                errors.append(f"{it['id']}: disc contains unknown values {bad}")
        for dfield in ('due', 'date'):
            if dfield in it and not re.match(r'^\d{4}-\d{2}-\d{2}$', it[dfield]):
                errors.append(f"{it['id']}: malformed {dfield} '{it[dfield]}'")
    for did in details:
        if did not in ids:
            errors.append(f"orphaned details entry: {did} (no matching item id)")
    return errors


def diff_previous(items, details, prev):
    errors, warnings = [], []
    prev_items = {norm_title(p['title']): p for p in prev.get('items', [])}
    prev_details = prev.get('details', {})
    new_titles = {norm_title(it['title']) for it in items}

    known_programs = {p['name'] for p in prev.get('programs', [])}
    if known_programs:
        for it in items:
            if it['program'] not in known_programs and it['status'] != 'completed':
                warnings.append(f"'{it['title'][:50]}' is under program '{it['program']}' "
                                f"which isn't in data.json programs — it won't render on the site")

    for nt, p in prev_items.items():
        if nt not in new_titles and p.get('status') != 'completed':
            errors.append(f"DROPPED item vs previous: '{p['title'][:70]}' "
                          f"({p.get('program','')}/{p.get('pkg','')}) — complete it in the vault or restore it")

    for it in items:
        nt = norm_title(it['title'])
        p = prev_items.get(nt)
        if p is None:
            it['isNew'] = True
            continue
        it.pop('isNew', None)
        pd = prev_details.get(p.get('id', ''), {})
        nd = details.get(it['id'], {})
        if len(nd.get('updates', [])) < len(pd.get('updates', [])):
            errors.append(f"SHRUNK updates on '{it['title'][:60]}': "
                          f"{len(pd.get('updates', []))} -> {len(nd.get('updates', []))}")
        if len(nd.get('subtasks', [])) < len(pd.get('subtasks', [])):
            warnings.append(f"fewer subtasks on '{it['title'][:60]}': "
                            f"{len(pd.get('subtasks', []))} -> {len(nd.get('subtasks', []))} "
                            f"(fine if completed subtasks were pruned)")
        if p.get('why') and 'why' not in it:
            warnings.append(f"'why' text lost on '{it['title'][:60]}' (was: {p['why'][:50]}…)")
        if p.get('meta') and 'meta' not in it:
            warnings.append(f"'meta' text lost on '{it['title'][:60]}'")
    return errors, warnings


def build_full(items, details, prev):
    out = {}
    if prev.get('apiUrl'):
        out['apiUrl'] = prev['apiUrl']
    out['meta'] = dict(prev.get('meta', {}))
    out['meta']['generated'] = date.today().isoformat()
    for section in ('programs', 'voice', 'completedThisWeek', 'completedLastWeek'):
        if section in prev:
            out[section] = prev[section]
    slim = {}
    for iid, d in details.items():
        entry = {k: v for k, v in (('next', d['next']), ('subtasks', d['subtasks']),
                                   ('updates', d['updates'])) if v}
        if entry:
            slim[iid] = entry
    out['items'] = items
    out['details'] = slim
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sources', nargs='+')
    ap.add_argument('--prev')
    ap.add_argument('--out')
    args = ap.parse_args()

    items, details = [], {}
    for src in args.sources:
        with open(src, encoding='utf-8') as f:
            i2, d2 = parse_tasks_md(f.read())
        items.extend(i2)
        details.update(d2)

    errors = validate(items, details)
    warnings = []
    prev = {}
    if args.prev:
        with open(args.prev, encoding='utf-8') as f:
            prev = json.load(f)
        derr, warnings = diff_previous(items, details, prev)
        errors.extend(derr)

    for w in warnings:
        print(f'// WARN: {w}', file=sys.stderr)
    for e in errors:
        print(f'// ERROR: {e}', file=sys.stderr)
    print(f'// Parsed {len(items)} items from {len(args.sources)} file(s). '
          f"Validation: {'CLEAN' if not errors else str(len(errors)) + ' error(s)'}", file=sys.stderr)

    if errors:
        print('// Nothing written.', file=sys.stderr)
        return 1

    full = build_full(items, details, prev)
    text = json.dumps(full, indent=2, ensure_ascii=False)
    if args.out:
        with open(args.out, 'w', encoding='utf-8') as f:
            f.write(text + '\n')
        print(f'// Wrote {args.out}', file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == '__main__':
    sys.exit(main())
